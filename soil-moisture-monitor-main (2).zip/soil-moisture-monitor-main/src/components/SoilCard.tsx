import { Card } from '@/components/ui/card';
import { SoilProfile, SoilReading } from '@/types/soil';
import { getStatusColor } from '@/utils/soilAnalysis';
import { Droplets } from 'lucide-react';

interface SoilCardProps {
  profile: SoilProfile;
  reading: SoilReading;
}

const SoilCard = ({ profile, reading }: SoilCardProps) => {
  const statusColor = getStatusColor(reading.status);
  const moisturePercent = Math.min(100, (reading.moisture / profile.criticalMax) * 100);

  return (
    <Card className="group relative overflow-hidden transition-all duration-300 hover:shadow-lg hover:-translate-y-1 bg-card border-2 hover:border-primary/30">
      {/* Background gradient based on moisture */}
      <div
        className="absolute inset-0 opacity-5 transition-opacity duration-500"
        style={{
          background: `linear-gradient(135deg, ${statusColor}, transparent)`,
        }}
      />

      <div className="relative p-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <span className="text-4xl">{profile.icon}</span>
            <div>
              <h3 className="font-bold text-xl text-foreground">{profile.name}</h3>
              <p className="text-xs text-muted-foreground">{profile.description}</p>
            </div>
          </div>
        </div>

        {/* Moisture Display */}
        <div className="mb-4">
          <div className="flex items-end justify-between mb-2">
            <div className="flex items-center gap-2">
              <Droplets className="w-5 h-5 text-primary" />
              <span className="text-sm font-medium text-muted-foreground">Moisture Level</span>
            </div>
            <span
              className="text-3xl font-bold transition-colors duration-300"
              style={{ color: statusColor }}
            >
              {reading.moisture}%
            </span>
          </div>

          {/* Moisture Bar */}
          <div className="relative h-3 bg-muted rounded-full overflow-hidden">
            {/* Optimal Range Indicator */}
            <div
              className="absolute h-full bg-success/20"
              style={{
                left: `${(profile.optimalMin / profile.criticalMax) * 100}%`,
                width: `${((profile.optimalMax - profile.optimalMin) / profile.criticalMax) * 100}%`,
              }}
            />
            
            {/* Current Moisture Level */}
            <div
              className="absolute h-full transition-all duration-700 ease-out rounded-full"
              style={{
                width: `${moisturePercent}%`,
                background: statusColor,
              }}
            />
          </div>

          {/* Range Labels */}
          <div className="flex justify-between mt-1 text-xs text-muted-foreground">
            <span>0%</span>
            <span className="text-success">
              {profile.optimalMin}%-{profile.optimalMax}%
            </span>
            <span>{profile.criticalMax}%</span>
          </div>
        </div>

        {/* Status Badge */}
        <div
          className="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold mb-3 transition-all duration-300"
          style={{
            backgroundColor: `${statusColor}20`,
            color: statusColor,
          }}
        >
          {reading.status.replace('-', ' ').toUpperCase()}
        </div>

        {/* Recommendation */}
        <p className="text-sm text-foreground/80 leading-relaxed">
          {reading.recommendation}
        </p>

        {/* Last Updated */}
        <p className="text-xs text-muted-foreground mt-3">
          Updated: {reading.lastUpdated.toLocaleTimeString()}
        </p>
      </div>
    </Card>
  );
};

export default SoilCard;
